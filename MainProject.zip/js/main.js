document.addEventListener("DOMContentLoaded", () => {
  const navbar = document.getElementById("navbar");
  if (navbar) {
    window.addEventListener("scroll", () => {
      navbar.classList.toggle("scrolled", window.scrollY > 40);
    });
  }
  const hamburger = document.getElementById("hamburger");
  const mobileMenu = document.getElementById("mobileMenu");
  if (hamburger && mobileMenu) {
    hamburger.addEventListener("click", () => {
      hamburger.classList.toggle("open");
      mobileMenu.classList.toggle("open");
    });
    mobileMenu.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        hamburger.classList.remove("open");
        mobileMenu.classList.remove("open");
      });
    });
  }
  const revealEls = document.querySelectorAll(".reveal");
  if (revealEls.length) {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add("visible");
            observer.unobserve(e.target);
          }
        });
      },
      { threshold: 0.1 },
    );
    revealEls.forEach((el) => observer.observe(el));
  }
});
const Validator = {
  isEmail(val) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val);
  },
  isPhone(val) {
    return /^[6-9]\d{9}$/.test(val.replace(/\s/g, ""));
  },
  isStrongPassword(val) {
    return val.length >= 8;
  },
  isEmpty(val) {
    return !val || val.trim() === "";
  },
  showError(inputEl, message) {
    inputEl.classList.add("error");
    const errEl = inputEl.parentElement.querySelector(".form-error");
    if (errEl) {
      errEl.textContent = message;
      errEl.classList.add("show");
    }
  },
  clearError(inputEl) {
    inputEl.classList.remove("error");
    const errEl = inputEl.parentElement.querySelector(".form-error");
    if (errEl) errEl.classList.remove("show");
  },
  clearAll(formEl) {
    formEl
      .querySelectorAll(".form-input, .form-select, .form-textarea")
      .forEach((el) => {
        this.clearError(el);
      });
  },
};
function showToast(message, type = "info", duration = 3500) {
  let container = document.getElementById("toast-container");
  if (!container) {
    container = document.createElement("div");
    container.id = "toast-container";
    container.style.cssText = `
      position: fixed; bottom: 2rem; right: 2rem;
      display: flex; flex-direction: column; gap: 10px;
      z-index: 9999; pointer-events: none;
    `;
    document.body.appendChild(container);
  }

  const colors = {
    success: {
      bg: "rgba(0,200,100,0.12)",
      border: "rgba(0,200,100,0.3)",
      color: "#4ade80",
    },
    error: {
      bg: "rgba(247,37,133,0.12)",
      border: "rgba(247,37,133,0.3)",
      color: "#f72585",
    },
    info: {
      bg: "rgba(0,229,255,0.1)",
      border: "rgba(0,229,255,0.25)",
      color: "#00e5ff",
    },
  };
  const c = colors[type] || colors.info;

  const toast = document.createElement("div");
  toast.style.cssText = `
    background: ${c.bg}; border: 1px solid ${c.border}; color: ${c.color};
    padding: 14px 20px; border-radius: 8px;
    font-family: 'JetBrains Mono', monospace; font-size: 0.83rem;
    backdrop-filter: blur(12px);
    transform: translateX(120%); transition: transform 0.35s cubic-bezier(0.4,0,0.2,1);
    pointer-events: all; max-width: 320px; line-height: 1.4;
    box-shadow: 0 8px 24px rgba(0,0,0,0.4);
  `;
  toast.textContent = message;
  container.appendChild(toast);

  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      toast.style.transform = "translateX(0)";
    });
  });

  setTimeout(() => {
    toast.style.transform = "translateX(120%)";
    setTimeout(() => toast.remove(), 400);
  }, duration);
}
function setButtonLoading(btn, loading, originalText = "") {
  if (loading) {
    btn.dataset.original = btn.innerHTML;
    btn.innerHTML = '<span class="spinner"></span> Processing...';
    btn.disabled = true;
    btn.style.opacity = "0.7";
  } else {
    btn.innerHTML = btn.dataset.original || originalText;
    btn.disabled = false;
    btn.style.opacity = "1";
  }
}
function getParam(name) {
  return new URLSearchParams(window.location.search).get(name);
}
function formatDate(dateStr) {
  const d = new Date(dateStr);
  return d.toLocaleDateString("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}
function confirmAction(message) {
  return window.confirm(message);
}
