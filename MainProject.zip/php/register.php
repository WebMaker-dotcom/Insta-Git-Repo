<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
session_start();
require_once 'db.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
    exit;
}
function clean($val)
{
    return htmlspecialchars(strip_tags(trim($val)));
}
$first_name  = clean($_POST['first_name']  ?? '');
$last_name   = clean($_POST['last_name']   ?? '');
$email       = filter_var(trim($_POST['email'] ?? ''), FILTER_SANITIZE_EMAIL);
$phone       = clean($_POST['phone']       ?? '');
$department  = clean($_POST['department']  ?? '');
$semester    = clean($_POST['semester']    ?? '');
$roll_no     = clean($_POST['roll_no']     ?? '');
$password    = $_POST['password']          ?? '';
$event_ids   = $_POST['events']            ?? [];  
$errors = [];
if (empty($first_name))                          $errors[] = 'First name is required.';
if (empty($last_name))                           $errors[] = 'Last name is required.';
if (!filter_var($email, FILTER_VALIDATE_EMAIL))  $errors[] = 'Invalid email address.';
if (!preg_match('/^[6-9]\d{9}$/', $phone))       $errors[] = 'Invalid phone number.';
if (empty($department))                          $errors[] = 'Department is required.';
if (empty($semester))                            $errors[] = 'Semester is required.';
if (empty($roll_no))                             $errors[] = 'Roll number is required.';
if (strlen($password) < 8)                       $errors[] = 'Password must be at least 8 characters.';
if (empty($event_ids))                           $errors[] = 'Please select at least one event.';
if (!empty($errors)) {
    echo json_encode(['success' => false, 'message' => implode(' ', $errors)]);
    exit;
}
$stmt = $conn->prepare('SELECT id FROM users WHERE email = ?');
$stmt->bind_param('s', $email);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows > 0) {
    echo json_encode(['success' => false, 'message' => 'This email is already registered.']);
    $stmt->close();
    exit;
}
$stmt->close();
$upload_dir = '../uploads/';
if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);
function uploadFile($fileKey, $upload_dir, $prefix)
{
    if (!isset($_FILES[$fileKey]) || $_FILES[$fileKey]['error'] !== UPLOAD_ERR_OK) {
        return null;
    }
    $file      = $_FILES[$fileKey];
    $allowed   = ['image/jpeg', 'image/png', 'application/pdf'];
    $max_size  = 2 * 1024 * 1024; // 2MB
    if (!in_array($file['type'], $allowed)) return ['error' => 'Invalid file type for ' . $fileKey];
    if ($file['size'] > $max_size)          return ['error' => 'File too large (max 2MB) for ' . $fileKey];
    $ext      = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = $prefix . '_' . uniqid() . '.' . strtolower($ext);
    $dest     = $upload_dir . $filename;
    if (!move_uploaded_file($file['tmp_name'], $dest)) {
        return ['error' => 'Failed to save ' . $fileKey];
    }
    return ['path' => 'uploads/' . $filename];
}
$id_upload      = uploadFile('id_card', $upload_dir, 'id');
$receipt_upload = uploadFile('receipt', $upload_dir, 'receipt');
if (is_array($id_upload) && isset($id_upload['error'])) {
    echo json_encode(['success' => false, 'message' => $id_upload['error']]);
    exit;
}
if (is_array($receipt_upload) && isset($receipt_upload['error'])) {
    echo json_encode(['success' => false, 'message' => $receipt_upload['error']]);
    exit;
}
$id_path      = $id_upload      ? $id_upload['path']      : null;
$receipt_path = $receipt_upload ? $receipt_upload['path']  : null;
$hashed_password = password_hash($password, PASSWORD_BCRYPT);
$stmt = $conn->prepare(
    'INSERT INTO users (first_name, last_name, email, phone, department, semester, roll_no, password)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
);
$stmt->bind_param(
    'ssssssss',
    $first_name,
    $last_name,
    $email,
    $phone,
    $department,
    $semester,
    $roll_no,
    $hashed_password
);
if (!$stmt->execute()) {
    echo json_encode(['success' => false, 'message' => 'Could not save user: ' . $stmt->error]);
    $stmt->close();
    exit;
}
$user_id = $stmt->insert_id;
$stmt->close();
$reg_id = null;
foreach ($event_ids as $event_id) {
    $event_id = intval($event_id);
    $slot_stmt = $conn->prepare('SELECT total_slots, filled_slots FROM events WHERE id = ?');
    $slot_stmt->bind_param('i', $event_id);
    $slot_stmt->execute();
    $slot_result = $slot_stmt->get_result();
    $event_row   = $slot_result->fetch_assoc();
    $slot_stmt->close();
    if (!$event_row) continue;
    if ($event_row['filled_slots'] >= $event_row['total_slots']) {
        continue;
    }
    $ins = $conn->prepare(
        'INSERT INTO registrations (user_id, event_id, status, id_card_path, receipt_path)
         VALUES (?, ?, "pending", ?, ?)'
    );
    $ins->bind_param('iiss', $user_id, $event_id, $id_path, $receipt_path);
    $ins->execute();
    if (!$reg_id) $reg_id = $ins->insert_id;
    $ins->close();
    $upd = $conn->prepare('UPDATE events SET filled_slots = filled_slots + 1 WHERE id = ?');
    $upd->bind_param('i', $event_id);
    $upd->execute();
    $upd->close();
}
$_SESSION['user_id']   = $user_id;
$_SESSION['user_name'] = $first_name . ' ' . $last_name;
$_SESSION['user_role'] = 'student';
echo json_encode([
    'success' => true,
    'message' => 'Registration successful!',
    'reg_id'  => $reg_id ?? $user_id,
    'user_id' => $user_id,
]);
$conn->close();
?>