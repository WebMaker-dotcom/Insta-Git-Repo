<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
session_start();
require_once 'db.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
    exit;
}
$role = trim($_POST['role'] ?? 'student');
if ($role === 'student') {
    $email    = filter_var(trim($_POST['email'] ?? ''), FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'] ?? '';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'message' => 'Enter a valid email address.']);
        exit;
    }
    if (empty($password)) {
        echo json_encode(['success' => false, 'message' => 'Password is required.']);
        exit;
    }
    $stmt = $conn->prepare(
        'SELECT id, first_name, last_name, email, password FROM users WHERE email = ? LIMIT 1'
    );
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user   = $result->fetch_assoc();
    $stmt->close();
    if (!$user || !password_verify($password, $user['password'])) {
        echo json_encode(['success' => false, 'message' => 'Invalid email or password.']);
        exit;
    }
    $_SESSION['user_id']   = $user['id'];
    $_SESSION['user_name'] = $user['first_name'] . ' ' . $user['last_name'];
    $_SESSION['user_email']= $user['email'];
    $_SESSION['user_role'] = 'student';
    echo json_encode([
        'success'   => true,
        'message'   => 'Login successful.',
        'user_id'   => $user['id'],
        'user_name' => $_SESSION['user_name'],
        'redirect'  => '../dashboard.html',
    ]);
    exit;
}
if ($role === 'admin') {
    $username = htmlspecialchars(strip_tags(trim($_POST['username'] ?? '')));
    $password = $_POST['password'] ?? '';
    if (empty($username) || empty($password)) {
        echo json_encode(['success' => false, 'message' => 'Username and password are required.']);
        exit;
    }
    $stmt = $conn->prepare(
        'SELECT id, username, password FROM admin_users WHERE username = ? LIMIT 1'
    );
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $admin  = $result->fetch_assoc();
    $stmt->close();
    if (!$admin || !password_verify($password, $admin['password'])) {
        echo json_encode(['success' => false, 'message' => 'Invalid admin credentials.']);
        exit;
    }
    $_SESSION['admin_id']   = $admin['id'];
    $_SESSION['admin_name'] = $admin['username'];
    $_SESSION['user_role']  = 'admin';
    echo json_encode([
        'success'   => true,
        'message'   => 'Admin login successful.',
        'redirect'  => '../admin/index.php',
    ]);
    exit;
}
echo json_encode(['success' => false, 'message' => 'Invalid role specified.']);
$conn->close();
?>