<?php
header('Content-Type: application/json');
session_start();
require_once 'db.php';
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Unauthorized. Admin access required.']);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
    exit;
}
$reg_id = intval($_POST['reg_id'] ?? 0);
$action = trim($_POST['action'] ?? '');   
if ($reg_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid registration ID.']);
    exit;
}
if (!in_array($action, ['approve', 'reject'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid action. Use "approve" or "reject".']);
    exit;
}
$new_status = $action === 'approve' ? 'approved' : 'rejected';
$check = $conn->prepare('SELECT status, event_id FROM registrations WHERE id = ?');
$check->bind_param('i', $reg_id);
$check->execute();
$check->bind_result($current_status, $event_id);
$check->fetch();
$check->close();
if (empty($current_status)) {
    echo json_encode(['success' => false, 'message' => 'Registration not found.']);
    exit;
}
$stmt = $conn->prepare('UPDATE registrations SET status = ? WHERE id = ?');
$stmt->bind_param('si', $new_status, $reg_id);
if (!$stmt->execute()) {
    echo json_encode(['success' => false, 'message' => 'Could not update status: ' . $stmt->error]);
    $stmt->close();
    exit;
}
$stmt->close();
if ($action === 'reject' && $current_status === 'approved') {
    $upd = $conn->prepare('UPDATE events SET filled_slots = GREATEST(0, filled_slots - 1) WHERE id = ?');
    $upd->bind_param('i', $event_id);
    $upd->execute();
    $upd->close();
}
if ($action === 'approve' && $current_status === 'rejected') {
    $upd = $conn->prepare('UPDATE events SET filled_slots = filled_slots + 1 WHERE id = ?');
    $upd->bind_param('i', $event_id);
    $upd->execute();
    $upd->close();
}
echo json_encode([
    'success'    => true,
    'message'    => 'Registration ' . $new_status . ' successfully.',
    'reg_id'     => $reg_id,
    'new_status' => $new_status,
]);
$conn->close();
?>
 