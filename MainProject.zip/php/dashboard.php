<?php
header('Content-Type: application/json');
session_start();
require_once 'db.php';
if (!isset($_SESSION['user_id']) || ($_SESSION['user_role'] ?? '') !== 'student') {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Not logged in.', 'redirect' => '../login.html']);
    exit;
}
$user_id = intval($_SESSION['user_id']);
$stmt = $conn->prepare(
    'SELECT id, first_name, last_name, email, phone, department, semester, roll_no, created_at
     FROM users WHERE id = ? LIMIT 1'
);
$stmt->bind_param('i', $user_id);
$stmt->execute();
$result  = $stmt->get_result();
$student = $result->fetch_assoc();
$stmt->close();
if (!$student) {
    echo json_encode(['success' => false, 'message' => 'Student not found.']);
    exit;
}
$reg_stmt = $conn->prepare(
    'SELECT r.id, r.status, r.registered_at, r.receipt_path,
            e.id AS event_id, e.title, e.category, e.event_date,
            e.venue, e.fee
     FROM registrations r
     JOIN events e ON r.event_id = e.id
     WHERE r.user_id = ?
     ORDER BY r.registered_at DESC'
);
$reg_stmt->bind_param('i', $user_id);
$reg_stmt->execute();
$reg_result = $reg_stmt->get_result();
$registrations = [];
while ($row = $reg_result->fetch_assoc()) {
    $row['event_id'] = (int)$row['event_id'];
    $row['fee']      = (int)$row['fee'];
    $registrations[] = $row;
}
$reg_stmt->close();
$total_fee = array_sum(array_column($registrations, 'fee'));
$approved  = count(array_filter($registrations, fn($r) => $r['status'] === 'approved'));
$pending   = count(array_filter($registrations, fn($r) => $r['status'] === 'pending'));
echo json_encode([
    'success'       => true,
    'student'       => $student,
    'registrations' => $registrations,
    'stats' => [
        'total'     => count($registrations),
        'approved'  => $approved,
        'pending'   => $pending,
        'total_fee' => $total_fee,
    ],
]);
$conn->close();
?>