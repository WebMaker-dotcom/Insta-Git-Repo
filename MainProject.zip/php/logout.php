<?php
session_start();
session_unset();
session_destroy();
if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) || isset($_SERVER['HTTP_ACCEPT']) && str_contains($_SERVER['HTTP_ACCEPT'], 'application/json')) {
    header('Content-Type: application/json');
    echo json_encode(['success' => true, 'message' => 'Logged out.']);
    exit;
}
header('Location: ../login.html');
exit;
?>
 