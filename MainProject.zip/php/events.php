<?php
header('Content-Type: application/json');
require_once 'db.php';
$result = $conn->query(
    'SELECT id, title, description, category, event_date, venue, team_size,
            fee, prize, total_slots, filled_slots, banner_img
     FROM events
     ORDER BY event_date ASC'
);
if (!$result) {
    echo json_encode(['success' => false, 'message' => 'Could not fetch events.']);
    exit;
}
$events = [];
while ($row = $result->fetch_assoc()) {
    $row['id']          = (int)$row['id'];
    $row['fee']         = (int)$row['fee'];
    $row['total_slots'] = (int)$row['total_slots'];
    $row['filled_slots']= (int)$row['filled_slots'];
    $events[] = $row;
}
echo json_encode([
    'success' => true,
    'events'  => $events,
    'total'   => count($events),
]);
$conn->close();
?>